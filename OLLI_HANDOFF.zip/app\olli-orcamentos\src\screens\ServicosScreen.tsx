import React, { useCallback, useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, TextInput,
  TouchableOpacity, Alert, Modal, ScrollView, Image,
} from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import * as Haptics from 'expo-haptics';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors, Spacing, BorderRadius, Shadow } from '../theme';
import { EmptyState } from '../components/EmptyState';
import { GradientHeader } from '../components/GradientHeader';
import { OlliButton } from '../components/OlliButton';
import { OlliInput, OlliMoneyInput } from '../components/OlliInput';
import { AnimatedEntrance } from '../components/AnimatedEntrance';
import { getServicos, saveServico, deleteServico } from '../database/database';
import { ServicoItem, UNIDADES } from '../types';
import { formatCurrency } from '../utils/currency';
import { generateId } from '../utils/id';
import { nowISO } from '../utils/date';

function margemPct(preco?: number, custo?: number): string | null {
  if (!preco || !custo || custo === 0) return null;
  return `${Math.round(((preco - custo) / preco) * 100)}%`;
}

export default function ServicosScreen() {
  const nav = useNavigation();
  const [items, setItems] = useState<ServicoItem[]>([]);
  const [filtered, setFiltered] = useState<ServicoItem[]>([]);
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<Partial<ServicoItem> | null>(null);

  useFocusEffect(useCallback(() => { load(); }, []));

  async function load() {
    const all = await getServicos();
    setItems(all);
    applyFilter(all, query);
  }

  function applyFilter(data: ServicoItem[], q: string) {
    setFiltered(!q.trim() ? data : data.filter(s => s.nome.toLowerCase().includes(q.toLowerCase())));
  }

  async function handleSave() {
    if (!editing?.nome?.trim()) return;
    const s: ServicoItem = {
      id: editing.id ?? generateId(),
      nome: editing.nome!, descricao: editing.descricao,
      preco: editing.preco ?? 0, custo: editing.custo,
      unidade: editing.unidade ?? 'un', fotoUri: editing.fotoUri,
      criadoEm: editing.criadoEm ?? nowISO(),
    };
    await saveServico(s);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    setEditing(null);
    load();
  }

  async function pickFoto() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('Permissão', 'Permita o acesso às fotos.'); return; }
    const r = await ImagePicker.launchImageLibraryAsync({ quality: 0.7, allowsEditing: true, aspect: [1, 1] });
    if (!r.canceled) setEditing(p => p ? { ...p, fotoUri: r.assets[0].uri } : p);
  }

  return (
    <View style={styles.container}>
      <GradientHeader title="Serviços" subtitle={`${items.length} no catálogo`} onBack={() => nav.goBack()}>
        <View style={styles.searchBar}>
          <MaterialCommunityIcons name="magnify" size={20} color={Colors.onSurfaceVariant} />
          <TextInput style={styles.searchInput} placeholder="Buscar serviço..." value={query} onChangeText={q => { setQuery(q); applyFilter(items, q); }} placeholderTextColor={Colors.onSurfaceMuted} />
        </View>
      </GradientHeader>

      <FlatList
        data={filtered}
        keyExtractor={s => s.id}
        contentContainerStyle={{ padding: Spacing.base, gap: 10, flexGrow: 1 }}
        renderItem={({ item: s, index }) => (
          <AnimatedEntrance index={index}>
            <View style={styles.card}>
              {s.fotoUri ? <Image source={{ uri: s.fotoUri }} style={styles.thumb} /> : (
                <View style={[styles.thumb, styles.thumbPlaceholder]}><MaterialCommunityIcons name="wrench" size={22} color={Colors.primary} /></View>
              )}
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={styles.name}>{s.nome}</Text>
                {s.descricao ? <Text style={styles.desc} numberOfLines={1}>{s.descricao}</Text> : null}
                <View style={styles.tagsRow}>
                  <Text style={styles.price}>{formatCurrency(s.preco)} / {s.unidade}</Text>
                  {margemPct(s.preco, s.custo) && (
                    <View style={styles.margemTag}><Text style={styles.margemText}>lucro {margemPct(s.preco, s.custo)}</Text></View>
                  )}
                </View>
              </View>
              <View style={styles.cardActions}>
                <TouchableOpacity onPress={() => setEditing({ ...s })} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}><MaterialCommunityIcons name="pencil-outline" size={20} color={Colors.primary} /></TouchableOpacity>
                <TouchableOpacity onPress={() => Alert.alert('Excluir', `Excluir "${s.nome}"?`, [{ text: 'Cancelar', style: 'cancel' }, { text: 'Excluir', style: 'destructive', onPress: async () => { await deleteServico(s.id); load(); } }])} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                  <MaterialCommunityIcons name="trash-can-outline" size={20} color={Colors.danger} />
                </TouchableOpacity>
              </View>
            </View>
          </AnimatedEntrance>
        )}
        ListEmptyComponent={<EmptyState icon="wrench-outline" title="Nenhum serviço" subtitle="Cadastre seus serviços para montar orçamentos em segundos." actionLabel="Novo serviço" onAction={() => setEditing({ unidade: 'un', preco: 0 })} />}
      />

      <TouchableOpacity style={styles.fab} onPress={() => setEditing({ unidade: 'un', preco: 0 })} activeOpacity={0.85}>
        <MaterialCommunityIcons name="plus" size={28} color="#fff" />
      </TouchableOpacity>

      <Modal visible={!!editing} animationType="slide" onRequestClose={() => setEditing(null)}>
        {editing && (
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editing.id ? 'Editar Serviço' : 'Novo Serviço'}</Text>
              <TouchableOpacity onPress={() => setEditing(null)} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}><MaterialCommunityIcons name="close" size={26} color={Colors.onSurface} /></TouchableOpacity>
            </View>
            <ScrollView contentContainerStyle={{ padding: Spacing.base }} keyboardShouldPersistTaps="handled">
              <TouchableOpacity style={styles.fotoBtn} onPress={pickFoto} activeOpacity={0.8}>
                {editing.fotoUri ? <Image source={{ uri: editing.fotoUri }} style={styles.fotoPreview} /> : (
                  <><MaterialCommunityIcons name="camera-plus-outline" size={30} color={Colors.primary} /><Text style={styles.fotoBtnLabel}>Adicionar foto</Text></>
                )}
              </TouchableOpacity>
              <OlliInput label="Nome do serviço" required value={editing.nome ?? ''} onChangeText={v => setEditing(p => p ? { ...p, nome: v } : p)} placeholder="Ex: Instalação de ar condicionado" />
              <OlliInput label="Descrição" value={editing.descricao ?? ''} onChangeText={v => setEditing(p => p ? { ...p, descricao: v } : p)} placeholder="O que está incluso" multiline />
              <View style={styles.rowFields}>
                <OlliMoneyInput label="Preço de venda" value={editing.preco ?? 0} onChangeValue={v => setEditing(p => p ? { ...p, preco: v } : p)} containerStyle={{ flex: 1, marginRight: 10 }} />
                <OlliMoneyInput label="Custo (opcional)" value={editing.custo ?? 0} onChangeValue={v => setEditing(p => p ? { ...p, custo: v || undefined } : p)} containerStyle={{ flex: 1 }} />
              </View>
              {margemPct(editing.preco, editing.custo) && (
                <View style={styles.margemBanner}>
                  <MaterialCommunityIcons name="trending-up" size={18} color={Colors.success} />
                  <Text style={styles.margemBannerText}>Margem de {margemPct(editing.preco, editing.custo)} · Lucro {formatCurrency((editing.preco ?? 0) - (editing.custo ?? 0))}</Text>
                </View>
              )}
              <Text style={styles.unidadeLabel}>Unidade de medida</Text>
              <View style={styles.unidadesRow}>
                {UNIDADES.map(u => (
                  <TouchableOpacity key={u} style={[styles.unidade, editing.unidade === u && styles.unidadeActive]} onPress={() => setEditing(p => p ? { ...p, unidade: u } : p)}>
                    <Text style={[styles.unidadeText, editing.unidade === u && { color: Colors.onSurface }]}>{u}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
            <View style={styles.modalFooter}>
              <OlliButton label="Salvar serviço" variant="gradient" size="lg" fullWidth onPress={handleSave} disabled={!editing.nome?.trim()} icon={<MaterialCommunityIcons name="check" size={20} color="#fff" />} />
            </View>
          </View>
        )}
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surfaceVariant, borderRadius: BorderRadius.lg, paddingHorizontal: 14, paddingVertical: 11, gap: 8, marginTop: 14 },
  searchInput: { flex: 1, fontSize: 15, color: Colors.onSurface },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface, borderRadius: BorderRadius.lg, padding: Spacing.md, ...Shadow.sm },
  thumb: { width: 52, height: 52, borderRadius: BorderRadius.md },
  thumbPlaceholder: { backgroundColor: Colors.primaryContainer, justifyContent: 'center', alignItems: 'center' },
  name: { fontSize: 15, fontWeight: '700', color: Colors.onSurface },
  desc: { fontSize: 12, color: Colors.onSurfaceVariant, marginTop: 2 },
  tagsRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 5 },
  price: { fontSize: 13, color: Colors.primary, fontWeight: '700' },
  margemTag: { backgroundColor: Colors.successLight, borderRadius: BorderRadius.full, paddingHorizontal: 8, paddingVertical: 2 },
  margemText: { fontSize: 11, color: Colors.success, fontWeight: '700' },
  cardActions: { flexDirection: 'row', gap: 16, marginLeft: 8 },
  fab: { position: 'absolute', right: 20, bottom: 24, width: 58, height: 58, borderRadius: 29, backgroundColor: Colors.primary, justifyContent: 'center', alignItems: 'center', ...Shadow.lg, shadowColor: Colors.primary, shadowOpacity: 0.4 },
  modal: { flex: 1, backgroundColor: Colors.background },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.base, paddingVertical: Spacing.base, paddingTop: 56, backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.outline },
  modalTitle: { fontSize: 20, fontWeight: '800', color: Colors.onSurface },
  modalFooter: { padding: Spacing.base, paddingBottom: 28, backgroundColor: Colors.surface, borderTopWidth: 1, borderTopColor: Colors.outline },
  fotoBtn: { height: 120, borderRadius: BorderRadius.lg, borderWidth: 1.5, borderColor: Colors.primary, borderStyle: 'dashed', justifyContent: 'center', alignItems: 'center', marginBottom: Spacing.base, overflow: 'hidden', backgroundColor: Colors.primaryContainer + '40' },
  fotoPreview: { width: '100%', height: '100%' },
  fotoBtnLabel: { fontSize: 13, color: Colors.primary, fontWeight: '700', marginTop: 4 },
  margemBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: Colors.successLight, borderRadius: BorderRadius.md, padding: 12, marginBottom: Spacing.base },
  margemBannerText: { fontSize: 13, color: Colors.success, fontWeight: '700' },
  unidadeLabel: { fontSize: 13, fontWeight: '600', color: Colors.onSurfaceVariant, marginBottom: 8 },
  unidadesRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  unidade: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: BorderRadius.full, borderWidth: 1.5, borderColor: Colors.outline },
  unidadeActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  unidadeText: { fontSize: 13, fontWeight: '700', color: Colors.onSurfaceVariant },
  rowFields: { flexDirection: 'row' },
});
